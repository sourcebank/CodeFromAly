# Copyright (c) 2019 Philips Health Care North America <https://www.usa.philips.com/healthcare>
# This file is part of PyQt5.
# This file used in Automated Test Tool developed by Philips

import time


class StateMachine:

    def __init__(self):
        self.handlers = {}  # Dictionary act as pointer to states
        self.CurrentState = None
        self.ResetLoop = 0

    def updateStatemachine(self, val):
        self.ResetLoop = val

    def add_state(self, name, handler):
        name = name.upper()
        self.handlers[name] = handler

    def init(self, name):
        name = name.upper()
        self.CurrentState = name

    def AssignStates(self):
        self.add_state("Init_state", init_state)
        self.add_state("Idle_state", idle_state)
        self.add_state("FileRead_state", fileread_state)
        self.add_state("SendCommand_state", sendcommand_state)
        self.add_state("ReSendCommand_state", re_sendcommand_state)
        self.add_state("Verifyvalues_state", verifyvalues_state)
        self.add_state("Generatereport_state", generatereport_state)
        self.add_state("Error_state", error_state)
        self.init("Init_state")

    def run(self):
        handler = self.handlers[self.CurrentState](self)
        if handler != None:
            self.CurrentState = handler.upper()


def init_state(handle):
    print("Inside init")

    newState = "Idle_state"
    return (newState)


def idle_state(handle):  # Idle
    print("Inside Idle")

    if handle.ResetLoop == 1:
        newState = "Idle_state"
    else:
        newState = "FileRead_state"
    return (newState)


def fileread_state(handle):  # Read Json script
    print("Inside fileread")

    if handle.ResetLoop == 1:
        newState = "Idle_state"
    else:
        newState = "SendCommand_state"
    return (newState)


def sendcommand_state(handle):  # Send command to sensor
    print("Inside sendcommand")

    if handle.ResetLoop == 1:
        newState = "Idle_state"
    else:
        newState = "ReSendCommand_state"
    return (newState)


def re_sendcommand_state(handle):  # Resend command to sensor
    print("Inside re_sendcommand")

    if handle.ResetLoop == 1:
        newState = "Idle_state"
    else:
        newState = "Verifyvalues_state"
    return (newState)


def verifyvalues_state(handle):  # Verify the values
    print("Inside verifyvalues")

    if handle.ResetLoop == 1:
        newState = "Idle_state"
    else:
        newState = "Generatereport_state"
    return (newState)


def generatereport_state(handle):  # Generate report
    print("Inside generatereport")

    if handle.ResetLoop == 1:
        newState = "Idle_state"
    else:
        newState = "Init_state"
    return (newState)


def error_state():  # Error occured !!
    print("Inside Error")
    return (None)
