# Copyright (c) 2019 Philips Health Care North America <https://www.usa.philips.com/healthcare>
# This file is part of PyQt5.
# This file used in Automated Test Tool developed by Philips
import serial.tools.list_ports

def AvailableComPorts() -> list:
    """ Lists serial port names

        :returns:
            A list of the serial ports available on the system
    """
    comlist = serial.tools.list_ports.comports()
    available = []
    for element in comlist:
        available.append(element.device)

    return available