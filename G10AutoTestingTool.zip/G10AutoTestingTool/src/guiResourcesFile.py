# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Pyqt5_gui_resources.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_AppGUIclass(object):

    CountCOM = 0

    def setupUi(self, AppGUIclass):
        AppGUIclass.setObjectName("AppGUIclass")
        AppGUIclass.resize(659, 610)
        self.pushButton = QtWidgets.QPushButton(AppGUIclass)
        self.pushButton.setGeometry(QtCore.QRect(541, 570, 75, 23))
        self.pushButton.setObjectName("pushButton")
        self.groupBox = QtWidgets.QGroupBox(AppGUIclass)
        self.groupBox.setGeometry(QtCore.QRect(11, 455, 641, 100))
        self.groupBox.setObjectName("groupBox")
        self.pushButton_StartTest = QtWidgets.QPushButton(self.groupBox)
        self.pushButton_StartTest.setGeometry(QtCore.QRect(513, 25, 91, 41))
        self.pushButton_StartTest.setObjectName("pushButton_StartTest")
        self.label_13 = QtWidgets.QLabel(self.groupBox)
        self.label_13.setGeometry(QtCore.QRect(10, 30, 81, 16))
        self.label_13.setObjectName("label_13")
        self.textEdit_45 = QtWidgets.QTextEdit(self.groupBox)
        self.textEdit_45.setGeometry(QtCore.QRect(77, 24, 371, 31))
        self.textEdit_45.setObjectName("textEdit_45")
        self.progressBar = QtWidgets.QProgressBar(self.groupBox)
        self.progressBar.setGeometry(QtCore.QRect(140, 65, 301, 23))
        self.progressBar.setProperty("value", 24)
        self.progressBar.setObjectName("progressBar")
        self.label_14 = QtWidgets.QLabel(self.groupBox)
        self.label_14.setGeometry(QtCore.QRect(5, 64, 131, 20))
        self.label_14.setObjectName("label_14")
        self.groupBox_2 = QtWidgets.QGroupBox(AppGUIclass)
        self.groupBox_2.setGeometry(QtCore.QRect(9, 5, 641, 101))
        self.groupBox_2.setObjectName("groupBox_2")
        self.label_4 = QtWidgets.QLabel(self.groupBox_2)
        self.label_4.setGeometry(QtCore.QRect(11, 30, 81, 16))
        self.label_4.setObjectName("label_4")
        self.textEdit_10 = QtWidgets.QTextEdit(self.groupBox_2)
        self.textEdit_10.setGeometry(QtCore.QRect(97, 24, 391, 31))
        self.textEdit_10.setObjectName("textEdit_10")
        self.pushButton_Connect = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_Connect.setGeometry(QtCore.QRect(500, 27, 75, 23))
        self.pushButton_Connect.setObjectName("pushButton_Connect")
        self.label_5 = QtWidgets.QLabel(self.groupBox_2)
        self.label_5.setGeometry(QtCore.QRect(390, 70, 111, 16))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.groupBox_2)
        self.label_6.setGeometry(QtCore.QRect(500, 70, 101, 16))
        self.label_6.setObjectName("label_6")
        self.textEdit_44 = QtWidgets.QTextEdit(self.groupBox_2)
        self.textEdit_44.setGeometry(QtCore.QRect(96, 59, 271, 30))
        self.textEdit_44.setObjectName("textEdit_44")
        self.label_12 = QtWidgets.QLabel(self.groupBox_2)
        self.label_12.setGeometry(QtCore.QRect(19, 64, 81, 16))
        self.label_12.setObjectName("label_12")
        self.textEditMAC_5 = QtWidgets.QGroupBox(AppGUIclass)
        self.textEditMAC_5.setGeometry(QtCore.QRect(9, 106, 641, 350))
        self.textEditMAC_5.setObjectName("textEditMAC_5")
        self.label_3 = QtWidgets.QLabel(self.textEditMAC_5)
        self.label_3.setGeometry(QtCore.QRect(336, 30, 81, 16))
        self.label_3.setObjectName("label_3")
        self.textEdit = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit.setGeometry(QtCore.QRect(227, 51, 371, 31))
        self.textEdit.setObjectName("textEdit")
        self.textEditMAC_3 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC_3.setGeometry(QtCore.QRect(40, 122, 111, 31))
        self.textEditMAC_3.setObjectName("textEditMAC_3")
        self.textEditMAC_2 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC_2.setGeometry(QtCore.QRect(40, 86, 111, 30))
        self.textEditMAC_2.setObjectName("textEditMAC_2")
        self.label = QtWidgets.QLabel(self.textEditMAC_5)
        self.label.setGeometry(QtCore.QRect(60, 30, 71, 16))
        self.label.setObjectName("label")
        self.textEdit_2 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit_2.setGeometry(QtCore.QRect(226, 86, 371, 31))
        self.textEdit_2.setObjectName("textEdit_2")
        self.textEdit_3 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit_3.setGeometry(QtCore.QRect(226, 122, 371, 31))
        self.textEdit_3.setObjectName("textEdit_3")
        self.textEditMAC = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC.setGeometry(QtCore.QRect(40, 51, 111, 31))
        self.textEditMAC.setObjectName("textEditMAC")
        self.label_2 = QtWidgets.QLabel(self.textEditMAC_5)
        self.label_2.setGeometry(QtCore.QRect(172, 30, 60, 16))
        self.label_2.setObjectName("label_2")
        self.textEditMAC_6 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC_6.setGeometry(QtCore.QRect(40, 232, 111, 31))
        self.textEditMAC_6.setObjectName("textEditMAC_6")
        self.textEdit_4 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit_4.setGeometry(QtCore.QRect(226, 160, 371, 31))
        self.textEdit_4.setObjectName("textEdit_4")
        self.textEditMAC_9 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC_9.setGeometry(QtCore.QRect(40, 197, 111, 30))
        self.textEditMAC_9.setObjectName("textEditMAC_9")
        self.textEdit_5 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit_5.setGeometry(QtCore.QRect(226, 197, 371, 31))
        self.textEdit_5.setObjectName("textEdit_5")
        self.textEdit_6 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit_6.setGeometry(QtCore.QRect(226, 234, 371, 31))
        self.textEdit_6.setObjectName("textEdit_6")
        self.textEditMAC_4 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC_4.setGeometry(QtCore.QRect(40, 160, 111, 31))
        self.textEditMAC_4.setObjectName("textEditMAC_4")
        self.checkBox_2 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_2.setGeometry(QtCore.QRect(15, 57, 21, 17))
        self.checkBox_2.setText("")
        self.checkBox_2.setObjectName("checkBox_2")
        self.label_7 = QtWidgets.QLabel(self.textEditMAC_5)
        self.label_7.setGeometry(QtCore.QRect(10, 30, 31, 16))
        self.label_7.setObjectName("label_7")
        self.checkBox_3 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_3.setGeometry(QtCore.QRect(15, 91, 21, 17))
        self.checkBox_3.setText("")
        self.checkBox_3.setObjectName("checkBox_3")
        self.checkBox_6 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_6.setGeometry(QtCore.QRect(15, 127, 21, 20))
        self.checkBox_6.setText("")
        self.checkBox_6.setObjectName("checkBox_6")
        self.checkBox_7 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_7.setGeometry(QtCore.QRect(14, 166, 21, 17))
        self.checkBox_7.setText("")
        self.checkBox_7.setObjectName("checkBox_7")
        self.checkBox_8 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_8.setGeometry(QtCore.QRect(14, 201, 21, 17))
        self.checkBox_8.setText("")
        self.checkBox_8.setObjectName("checkBox_8")
        self.checkBox_9 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_9.setGeometry(QtCore.QRect(15, 237, 21, 17))
        self.checkBox_9.setText("")
        self.checkBox_9.setObjectName("checkBox_9")
        self.textEdit_7 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit_7.setGeometry(QtCore.QRect(227, 269, 371, 31))
        self.textEdit_7.setObjectName("textEdit_7")
        self.checkBox_10 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_10.setGeometry(QtCore.QRect(15, 272, 21, 17))
        self.checkBox_10.setText("")
        self.checkBox_10.setObjectName("checkBox_10")
        self.textEditMAC_7 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC_7.setGeometry(QtCore.QRect(41, 267, 111, 31))
        self.textEditMAC_7.setObjectName("textEditMAC_7")
        self.textEdit_8 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEdit_8.setGeometry(QtCore.QRect(228, 304, 371, 31))
        self.textEdit_8.setObjectName("textEdit_8")
        self.textEditMAC_8 = QtWidgets.QTextEdit(self.textEditMAC_5)
        self.textEditMAC_8.setGeometry(QtCore.QRect(42, 303, 111, 31))
        self.textEditMAC_8.setObjectName("textEditMAC_8")
        self.checkBox_11 = QtWidgets.QCheckBox(self.textEditMAC_5)
        self.checkBox_11.setGeometry(QtCore.QRect(15, 308, 21, 17))
        self.checkBox_11.setText("")
        self.checkBox_11.setObjectName("checkBox_11")
        self.toolButton = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton.setGeometry(QtCore.QRect(598, 50, 31, 31))
        self.toolButton.setObjectName("toolButton")
        self.comboBox = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox.setGeometry(QtCore.QRect(160, 51, 61, 31))
        self.comboBox.setEditable(False)
        self.comboBox.setCurrentText("")
        self.comboBox.setObjectName("comboBox")
        self.comboBox_2 = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox_2.setGeometry(QtCore.QRect(159, 87, 61, 30))
        self.comboBox_2.setEditable(False)
        self.comboBox_2.setCurrentText("")
        self.comboBox_2.setObjectName("comboBox_2")
        self.comboBox_3 = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox_3.setGeometry(QtCore.QRect(158, 122, 61, 31))
        self.comboBox_3.setEditable(False)
        self.comboBox_3.setCurrentText("")
        self.comboBox_3.setObjectName("comboBox_3")
        self.comboBox_4 = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox_4.setGeometry(QtCore.QRect(159, 160, 61, 31))
        self.comboBox_4.setEditable(False)
        self.comboBox_4.setCurrentText("")
        self.comboBox_4.setObjectName("comboBox_4")
        self.comboBox_5 = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox_5.setGeometry(QtCore.QRect(158, 196, 61, 31))
        self.comboBox_5.setEditable(False)
        self.comboBox_5.setCurrentText("")
        self.comboBox_5.setObjectName("comboBox_5")
        self.comboBox_6 = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox_6.setGeometry(QtCore.QRect(157, 232, 61, 31))
        self.comboBox_6.setEditable(False)
        self.comboBox_6.setCurrentText("")
        self.comboBox_6.setObjectName("comboBox_6")
        self.comboBox_7 = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox_7.setGeometry(QtCore.QRect(157, 267, 61, 31))
        self.comboBox_7.setEditable(False)
        self.comboBox_7.setCurrentText("")
        self.comboBox_7.setObjectName("comboBox_7")
        self.comboBox_8 = QtWidgets.QComboBox(self.textEditMAC_5)
        self.comboBox_8.setGeometry(QtCore.QRect(158, 302, 61, 31))
        self.comboBox_8.setEditable(False)
        self.comboBox_8.setCurrentText("")
        self.comboBox_8.setObjectName("comboBox_8")
        self.toolButton_2 = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton_2.setGeometry(QtCore.QRect(597, 85, 31, 31))
        self.toolButton_2.setObjectName("toolButton_2")
        self.toolButton_3 = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton_3.setGeometry(QtCore.QRect(597, 121, 31, 31))
        self.toolButton_3.setObjectName("toolButton_3")
        self.toolButton_4 = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton_4.setGeometry(QtCore.QRect(597, 159, 31, 31))
        self.toolButton_4.setObjectName("toolButton_4")
        self.toolButton_5 = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton_5.setGeometry(QtCore.QRect(597, 197, 31, 31))
        self.toolButton_5.setObjectName("toolButton_5")
        self.toolButton_6 = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton_6.setGeometry(QtCore.QRect(597, 233, 31, 31))
        self.toolButton_6.setObjectName("toolButton_6")
        self.toolButton_7 = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton_7.setGeometry(QtCore.QRect(598, 268, 31, 31))
        self.toolButton_7.setObjectName("toolButton_7")
        self.toolButton_8 = QtWidgets.QToolButton(self.textEditMAC_5)
        self.toolButton_8.setGeometry(QtCore.QRect(599, 303, 31, 31))
        self.toolButton_8.setObjectName("toolButton_8")
        self.pushButton_getcom = QtWidgets.QPushButton(self.textEditMAC_5)
        self.pushButton_getcom.setGeometry(QtCore.QRect(500, 15, 75, 23))
        self.pushButton_getcom.setObjectName("pushButton_getcom")
        self.label_15 = QtWidgets.QLabel(AppGUIclass)
        self.label_15.setGeometry(QtCore.QRect(20, 570, 131, 20))
        self.label_15.setObjectName("label_15")
        self.label_STATUS = QtWidgets.QLabel(AppGUIclass)
        self.label_STATUS.setGeometry(QtCore.QRect(71, 571, 301, 16))
        self.label_STATUS.setObjectName("label_STATUS")
        self.pushButton_4 = QtWidgets.QPushButton(AppGUIclass)
        self.pushButton_4.setGeometry(QtCore.QRect(451, 570, 75, 23))
        self.pushButton_4.setObjectName("pushButton_4")

        self.retranslateUi(AppGUIclass)
        QtCore.QMetaObject.connectSlotsByName(AppGUIclass)

    def toolButtonClicked(self, editText):
        fileName, _ = QtWidgets.QFileDialog.getOpenFileName(None, "Open File", "", "JSON Files (*.json)")
        if fileName:
            editText.setPlainText(fileName)

    def GUI_UpdateStatus(self, text):
        self.label_STATUS.setText(text)

    def GUI_PopulateCOM(self):
        _translate = QtCore.QCoreApplication.translate
        print(self.CountCOM)
        x = 0
        for x in range(self.CountCOM):
            self.comboBox.removeItem(x)
            self.comboBox_2.removeItem(x)
            self.comboBox_3.removeItem(x)
            self.comboBox_4.removeItem(x)
            self.comboBox_5.removeItem(x)
            self.comboBox_6.removeItem(x)
            self.comboBox_7.removeItem(x)
            self.comboBox_8.removeItem(x)

        counter = 0
        x =0
        self.CountCOM  =0
        for x in self.comPorts:
            self.comboBox.addItem("")
            self.comboBox_2.addItem("")
            self.comboBox_3.addItem("")
            self.comboBox_4.addItem("")
            self.comboBox_5.addItem("")
            self.comboBox_6.addItem("")
            self.comboBox_7.addItem("")
            self.comboBox_8.addItem("")
            self.comboBox.setItemText(counter, _translate("AppGUIclass", x))
            self.comboBox_2.setItemText(counter, _translate("AppGUIclass", x))
            self.comboBox_3.setItemText(counter, _translate("AppGUIclass", x))
            self.comboBox_4.setItemText(counter, _translate("AppGUIclass", x))
            self.comboBox_5.setItemText(counter, _translate("AppGUIclass", x))
            self.comboBox_6.setItemText(counter, _translate("AppGUIclass", x))
            self.comboBox_7.setItemText(counter, _translate("AppGUIclass", x))
            self.comboBox_8.setItemText(counter, _translate("AppGUIclass", x))
            counter+=1
            self.CountCOM += 1;
        self.comboBox.setCurrentText(_translate("AppGUIclass", x))
        self.comboBox_2.setCurrentText(_translate("AppGUIclass", x))
        self.comboBox_3.setCurrentText(_translate("AppGUIclass", x))
        self.comboBox_4.setCurrentText(_translate("AppGUIclass", x))
        self.comboBox_5.setCurrentText(_translate("AppGUIclass", x))
        self.comboBox_6.setCurrentText(_translate("AppGUIclass", x))
        self.comboBox_7.setCurrentText(_translate("AppGUIclass", x))
        self.comboBox_8.setCurrentText(_translate("AppGUIclass", x))

    def GUI_UpdateStartStop(self):
        _translate = QtCore.QCoreApplication.translate
        if (self.pushButton_StartTest.text() == "Start Testing") :
            self.pushButton_StartTest.setText(_translate("AppGUIclass", "Stop Testing"))
        else:
            self.pushButton_StartTest.setText(_translate("AppGUIclass", "Start Testing"))

    def retranslateUi(self, AppGUIclass):
        _translate = QtCore.QCoreApplication.translate
        AppGUIclass.setWindowTitle(_translate("AppGUIclass", "Automated Test Tool - Seta Bridge"))
        self.pushButton.setText(_translate("AppGUIclass", "Exit"))
        self.groupBox.setTitle(_translate("AppGUIclass", "     Run "))
        self.pushButton_StartTest.setText(_translate("AppGUIclass", "Start Testing"))
        self.label_13.setText(_translate("AppGUIclass", "Report Path"))
        self.textEdit_45.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.label_14.setText(_translate("AppGUIclass", "Overall test completion %"))
        self.groupBox_2.setTitle(_translate("AppGUIclass", "Seta Configuration"))
        self.label_4.setText(_translate("AppGUIclass", "Websocket Data:"))
        self.textEdit_10.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">wss://192.168.1.25:7001/DataStream?SourceSystemId=CSVAdmin@philips</p></body></html>"))
        self.pushButton_Connect.setText(_translate("AppGUIclass", "Connect"))
        self.label_5.setText(_translate("AppGUIclass", "Connection Status:"))
        self.label_6.setText(_translate("AppGUIclass", "DISCONNECTED"))
        self.textEdit_44.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">YY141308\\\\SQLEXPRESS</p></body></html>"))
        self.label_12.setText(_translate("AppGUIclass", "SQL server"))
        self.textEditMAC_5.setTitle(_translate("AppGUIclass", "Port settings"))
        self.label_3.setText(_translate("AppGUIclass", "JSON file path"))
        self.textEdit.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON1</p></body></html>"))
        self.textEditMAC_3.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">12:01:10:F8:66:66</p></body></html>"))
        self.textEditMAC_2.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">AA:F0:12:FC:56:20</p></body></html>"))
        self.label.setText(_translate("AppGUIclass", "Dongle MAC"))
        self.textEdit_2.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON2</p></body></html>"))
        self.textEdit_3.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON4</p></body></html>"))
        self.textEditMAC.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">DC:08:17:FC:55:2A</p></body></html>"))
        self.label_2.setText(_translate("AppGUIclass", "COM port"))
        self.textEditMAC_6.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">12:01:10:F8:66:66</p></body></html>"))
        self.textEdit_4.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON1</p></body></html>"))
        self.textEditMAC_9.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">AA:F0:12:FC:56:20</p></body></html>"))
        self.textEdit_5.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON2</p></body></html>"))
        self.textEdit_6.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON4</p></body></html>"))
        self.textEditMAC_4.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">DC:08:17:FC:55:2A</p></body></html>"))
        self.label_7.setText(_translate("AppGUIclass", "Enable"))
        self.textEdit_7.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON4</p></body></html>"))
        self.textEditMAC_7.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">12:01:10:F8:66:66</p></body></html>"))
        self.textEdit_8.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">C:\\Users\\320042811\\Desktop\\Automating Testtool\\UI\\JSON4</p></body></html>"))
        self.textEditMAC_8.setHtml(_translate("AppGUIclass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">12:01:10:F8:66:66</p></body></html>"))
        self.toolButton.setText(_translate("AppGUIclass", "..."))
        self.toolButton.clicked.connect(lambda: self.toolButtonClicked(self.textEdit))
        self.toolButton_2.setText(_translate("AppGUIclass", "..."))
        self.toolButton_2.clicked.connect(lambda: self.toolButtonClicked(self.textEdit_2))
        self.toolButton_3.setText(_translate("AppGUIclass", "..."))
        self.toolButton_3.clicked.connect(lambda: self.toolButtonClicked(self.textEdit_3))
        self.toolButton_4.setText(_translate("AppGUIclass", "..."))
        self.toolButton_4.clicked.connect(lambda: self.toolButtonClicked(self.textEdit_4))
        self.toolButton_5.setText(_translate("AppGUIclass", "..."))
        self.toolButton_5.clicked.connect(lambda: self.toolButtonClicked(self.textEdit_5))
        self.toolButton_6.setText(_translate("AppGUIclass", "..."))
        self.toolButton_6.clicked.connect(lambda: self.toolButtonClicked(self.textEdit_6))
        self.toolButton_7.setText(_translate("AppGUIclass", "..."))
        self.toolButton_7.clicked.connect(lambda: self.toolButtonClicked(self.textEdit_7))
        self.toolButton_8.setText(_translate("AppGUIclass", "..."))
        self.toolButton_8.clicked.connect(lambda: self.toolButtonClicked(self.textEdit_8))
        self.pushButton_getcom.setText(_translate("AppGUIclass", "Get COM list"))
        self.label_15.setText(_translate("AppGUIclass", "STATUS:  "))
        self.label_STATUS.setText(_translate("AppGUIclass", "Testing  tool is not connected to Seta"))
        self.pushButton_4.setText(_translate("AppGUIclass", "Save All"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    AppGUIclass = QtWidgets.QDialog()
    ui = Ui_AppGUIclass()
    ui.setupUi(AppGUIclass)
    AppGUIclass.show()
    sys.exit(app.exec_())

