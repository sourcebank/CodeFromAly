def printstatus(val):
    print('val =%d' % val)
