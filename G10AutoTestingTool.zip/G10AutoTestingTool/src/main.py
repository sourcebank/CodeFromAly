# Copyright (c) 2019 Philips Health Care North America <https://www.usa.philips.com/healthcare>
# This file is part of PyQt5.
# This file used in Automated Test Tool developed by Philips


# from simulator import Simulator, AvailableComPorts
# from database import Database
# from PyQt5 import QtWidgets
# from seta import Seta
# import json

import sys
from guiResourcesFile import Ui_AppGUIclass
from PyQt5 import QtCore, QtGui, QtWidgets
from ThreadHandle import MyThread
from LEDindicatorWidget import *
from stateMachine import *
from serialportcom import AvailableComPorts



# Create a new class for app inherited from GUI class
class MainProgramclass(Ui_AppGUIclass):
    message = "hello world"
    counter = 1
    comlist = []
    def __init__(self, dialog):
        Ui_AppGUIclass.__init__(self)
        self.setupUi(dialog)
        # Connect "Start testing" button with a custom function (activateTest)
        self.pushButton_StartTest.clicked.connect(self.ButtonPressed_StartTest)
        # Connect "COM" button with a custom function (activateTest)
        self.pushButton_getcom.clicked.connect(self.ClickedGetCOMList)

        print('Backend process thread created...')
        self.objMythread = MyThread(self, 1, 3)
        self.objMythread.start()

    def __del__(self): # Deleting (Calling destructor)
        print("main")
        del (self.objMythread)

    def ButtonPressed_StartTest(self):
        self.objMythread.UpdateStateMachine()
        self.GUI_UpdateStartStop()

        pass
    def ClickedGetCOMList(self):
        self.comPorts = AvailableComPorts()
        self.GUI_PopulateCOM()
        pass

    def MyPrint(self):
        print('Counter = %d' % self.counter)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    dialog = QtWidgets.QDialog()
    prog = MainProgramclass(dialog)
    dialog.show()

    sys.exit(app.exec_())
    print("Exited")

    #self.message = "How are you"
    #self.StatusUpdate()

