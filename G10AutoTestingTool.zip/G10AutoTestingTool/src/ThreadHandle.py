# Copyright (c) 2019 Philips Health Care North America <https://www.usa.philips.com/healthcare>
# This file is part of PyQt5.
# This file used in Automated Test Tool developed by Philips


from threading import Thread
import time
from stateMachine import *


class MyThread(Thread):
    val = 1

    def __init__(self, object, threadNo, interval):
        Thread.__init__(self)
        self.threadNo = threadNo
        self.interval = interval
        self.GUIobject = object
        self.objStateMachine = StateMachine()  # Create an object for state machine
        self.objStateMachine.AssignStates()

    def UpdateStateMachine(self):
        self.objStateMachine.updateStatemachine(1)


    def run(self):
        while (1):
            time.sleep(self.interval)
            if self.threadNo == 1:
                # printstatus(self.val)
                # self.GUIobject.StatusUpdate()
                # self.val += 1
                self.objStateMachine.run()
            elif self.threadNo == 2:
                print("Thread2")
            else:
                pass
